import time
import sys
import os
import sqlite3 as lite
import pandas as pd

from openpyxl import load_workbook
reload(sys)
sys.setdefaultencoding('utf-8')
ned_req_file = 'MAL207026912 OSHO property Holdings.xlsx'
study_template = 'rns_template.xlsm'

study_info = {}

def test():
    db_filename = r'c:\users\peace\documents\scripts\eskom\heatmap.db'
    con = lite.connect(db_filename)
    #con.text_factory = str
    feeder = study_info['Feeder'].upper()[:-1]
    substation = study_info['Substation'].upper()
    fdrs = con.execute('SELECT "Feeder" from test').fetchall()
    for fdr in fdrs:
        try:
            if feeder and substation in fdr[0].decode('utf-8'):
                feeder = fdr[0].decode('utf-8')
        except:
            pass
    #feeder_slections = 
    feeder_info = con.execute('SELECT "Voltage Class","Peak Demand (kVA)",\
                  "Installed Capacity (kVA)","Backbone Conductors",\
                  "Substation" from test WHERE Feeder = ?', (feeder,)).fetchall()
    backbone_con = ' ,'.join(str(e).replace('#', '') for e in feeder_info[0][3].split(';')[0::2]) 
    print(feeder_info)
    #con.execute("SELECT 'Voltage Class','Peak Demand','Bakbone Conductors', 'Installed Capacity (kVA)','Feeder','Substation' FROM test WHERE One = ?", "B")
    #fdr_md =
    #for fdr in fdrs:
        
    """"
    df.to_sql('test', con, flavor='sqlite',
                schema=None, if_exists='replace', index=True,
                index_label=None, chunksize=None, dtype=None)
    
    con.close()
    return study_info
    """
def get_user():
    import getpass, win32api
    username = getpass.getuser()
    names = win32api.GetUserName()
    print(username, names)
    
def get_info(ned_req_file):
    """ Get info from the request file. """
    wb = load_workbook(filename = ned_req_file)
    sheet_names = wb.get_sheet_names()
    cn_sheet = wb.get_sheet_by_name(sheet_names[0])
    for i in range(11,50):
        label = cn_sheet.cell(row=i,column=1).value or ''
        info = cn_sheet.cell(row=i,column=2).value or ''
        if ':' in label:
            study_info[label[:-1]] = info

def feeder_info():
    """ Get feeder info from heatmap. """
    db_filename = r'c:\users\peace\documents\scripts\eskom\heatmap.db'
    con = lite.connect(db_filename)
    #con.text_factory = str
    feeder = study_info['Feeder'].upper()[:-1]
    substation = study_info['Substation'].upper()
    fdrs = con.execute('SELECT "Feeder" from test').fetchall()
    for fdr in fdrs:
        try:
            if feeder in fdr[0].decode('utf-8'):
                feeder = fdr[0].decode('utf-8')
        except:
            pass
    #feeder_slections = 
    feeder_info = con.execute('SELECT "Voltage Class","Peak Demand (kVA)",\
                  "Installed Capacity (kVA)","Backbone Conductors",\
                  "Substation" from test WHERE Feeder = ?', (feeder,)).fetchall()
    feeder_info = [x for x in feeder_info[0]]
    feeder_info[3] = ', '.join(str(e).replace('#', '') for e in feeder_info[3].split(';')[0::2]) 
    return feeder_info

def perform_study(feeder):

def create_vbs():
    """ Create a vbs script to fill excel file. 
    Cells to fill: B5(r5,c2), B7(r7,c2), B11(r11,c2), B13, B15, B17, B19,B22, B23, E23, B24, E24
    B27, E27, B28, E28, B30, B31
    Results: B34, E34, B35, E35, B36, E36, B39, E39, B40, E40
    Graphs: A50:C62, D50:F62
    Connect: B64
    Recommendations: A68
    planner B73, senior b75, zone manager B 77
    return
    """
    vbs_items = []
    vbs_positions = ['(2,5)', '(2,7)', '(2,11)', '(2,13)', '(2,15)', '(2,17)', '(2,19)', '(2,22)', '(2,23)'
    from string import Template
    filein = open( 'fillstudyreport.vbs' )
    src = Template( filein.read() )
    revision = '0.0'
    project_num = study_info['Project Number']
    project_name = study_info['Project Name']
    study_project_id = '%s - %s' %(project_num, project_name)
    study_date = time.strftime("%Y%m%d")
    study_report = 'RNS_{0} - {1}_{2}_{3}.xlsx'.format(project_num, project_name, study_date, revision)
get_user()
#get_info(ned_req_file)
#print(feeder_info())
#print(study_info)
#test()
"""
def heatmap_info(feeder):
    # Get feeder info from heatmap_info

def simulate(feeder, load, work_type):
    # Simulate network 
    
def fill_report():
    #Fill the Network Study Template
    study_date = time.strftime("%Y%m%d")
    revision = '0.0'
    rns_book = load_workbook(filename = 'rns_template.xlsm')
    sheet = rns_book.active
    sheet['B5'] = '{0} - {1}'.format(project_num, project_name)
    sheet['B7'] = '{0} - {1}'.format(project_num, project_name)

    # Save new file and open it in Excel
    rns_report = 'RNS_{0} - {1}_{2}_{3}.xlsx'.format(project_num, project_name, study_date, revision)
    rns_book.save(rns_report)
    rns_book.close()
   try:
        os.system('excel {}'.format(rns_report))
    except:
        os.chdir('C:\Program Files (x86)\Microsoft Office\Office14')
        os.system('excel {}'.format(rns_report))	
"""   