import time
import sys
import os
import re
import getpass
import win32api
import datetime
import sqlite3 as lite
import pandas as pd

import rmd_sort

from openpyxl import load_workbook
reload(sys)
sys.setdefaultencoding('utf-8')
ned_req_file = 'MAS206545138B - Alexandra Village Pty Ltd.xlsx'
study_template = 'rns_template.xlsm'

study_info = {}


def test():
    wb = load_workbook(filename=ned_req_file)
    sheet_names = wb.get_sheet_names()
    cn_sheet = wb.get_sheet_by_name('1. Customer & Tech Info')
    boq_sheet = wb.get_sheet_by_name('4. BOQ')
    for i in range(11, 50):
        label = cn_sheet.cell(row=i, column=1).value or ''
        info = cn_sheet.cell(row=i, column=2).value or ''
        if ':' in label:
            study_info[label[:-1]] = info
    for row_index in range(1, boq_sheet.max_row):
        transformer = ''
        try:
            if 'TFR' in boq_sheet.cell(row=row_index, column=2).value:
                transformer = boq_sheet.cell(row=row_index, column=2).value
                if 'kVA' in transformer:
                    transformer = str(transformer).split()[1]
                    transformer = int(re.sub('[^0-9]','', transformer))
                    study_info['Transformer'] = transformer        
            if 'CT+VT' in boq_sheet.cell(row=row_index, column=2).value:
                transformer = boq_sheet.cell(row=row_index, column=2).value
                if study_info['New Load'] <= 500:
                    transformer = '500 BULK'
                elif study_info['New Load'] >= 1000:
                    transformer = '1000 BULK'
                else:
                    transformer = '<1000 BULK'                    
                
                study_info['Transformer'] = transformer
        except TypeError:
            pass
           


def get_user():
    """ Get Planner's name from Windows domain. """
    username = getpass.getuser()
    fullname = win32api.GetUserNameEx(3)
    print(username, fullname)


def get_info(ned_req_file):
    """ Get info from the request file. """
    wb = load_workbook(filename=ned_req_file)
    sheet_names = wb.get_sheet_names()
    cn_sheet = wb.get_sheet_by_name(sheet_names[0])
     
    for i in range(11, 50):
        label = cn_sheet.cell(row=i, column=1).value or ''
        info = cn_sheet.cell(row=i, column=2).value or ''
        if ':' in label:
            study_info[label[:-1]] = info
    nmd = int(re.sub('[^0-9]','', study_info['New NMD']))
    old_md = int(re.sub('[^0-9]','', study_info['Existing Notified Demand']))
    new_load =  nmd - old_md
    study_info['New Load'] = new_load

def feeder_info():
    """ Get feeder info from heatmap. """
    db_filename = r'c:\users\peace\documents\scripts\eskom\heatmap.db'
    con = lite.connect(db_filename)
    feeder = study_info['Feeder'].upper()[:-1]
    substation = study_info['Substation'].upper()
    fdrs = con.execute('SELECT "Feeder" from test').fetchall()
    for fdr in fdrs:
        try:
            if feeder in fdr[0].decode('utf-8'):
                feeder = fdr[0].decode('utf-8')
        except:
            pass
    feeder_info = con.execute('SELECT "Feeder","Substation","Voltage Class",\
                  "Peak Demand (kVA)","Installed Capacity (kVA)",\
                  "Backbone Conductors","Senior Engineer",\
                  "Respective Manager" from test WHERE Feeder = ?', (feeder,)
                              ).fetchall()
    feeder_info = [x for x in feeder_info[0]]
    backbone_con = feeder_info[5].split(';')[0::2]
    feeder_info[5] = ', '.join(str(e).replace('#', '') for e in backbone_con)
    return feeder_info

# def perform_study(feeder):


def create_vbs():
    """ Create a vbs script to fill excel file.
    Cells to fill: B5(r5,c2), B7(r7,c2), B9, B11(r11,c2), B13, B15, B17, B19,
    B22, B23, E23, B24, E24. B27, E27, B28, E28, B30, B31
    Results: B34, E34, B35, E35, B36, E36, B39, E39, B40, E40
    Graphs: A50:C62, D50:F62
    Connect: B64
    Recommendations: A68
    planner B73, senior b75, zone manager B 77
    return
    """
    
    project_num = study_info['Project Number']
    project_name = study_info['Project Name']
    study_project_id = '{0} - {1}'.format(project_num, project_name)
    supp_volt = study_info['Customer Supply Voltage']
    
    
    if 'k' in supp_volt:
        supp_volt = int(''.join(x for x in supp_volt if x.isdigit()))
    else:
        supp_volt = int(''.join(x for x in supp_volt if x.isdigit()))/1000
    
    if supp_volt == '0.23':
        study_info['Connection Phase'] = 'Single Phase'
    else:
        study_info['Connection Phase'] = 'Three Phase'
    
    vbs_items = [study_project_id, study_project_id, feeder_info[1],
                 feeder_info[0], study_info['Mini-sub/Pole No.'],
                 feeder_info[2], supp_volt, feeder_info[5]]
    vbs_positions = ['(2,5)', '(2,7)', '(2,9)', '(2,11)', '(2,13)', '(2,15)',
                     '(2,17)', '(2,19)', '(2,22)', '(2,23)', '(5,23)',
                     '(2,24)', '(5,24)', '(2,27)', '(5,27)', '(2,28)',
                     '(2,30)', '(2,31)', '(2,34)', '(5,34)', '(2,35)',
                     '(5,35)', '(2,36)', '(5,36)', '(2,39)', '(5,39)',
                     '(2,40)', '(5,40)', '(2,64)', '(1,68)', '(2,73)',
                     '(2,75)', '(2,77)']
    vbs_graphs = [('A50:C62', volt_profile_pic), ('D50:F62', curr_profile_pic)]
    from string import Template
    filein = open('fillstudyreport.vbs')
    src = Template(filein.read())
    revision = '0.0'
    
    study_date = time.strftime("%Y%m%d")
    study_report = 'RNS_{0} - {1}_{2}_{3}.xlsx'.format(project_num,
                                                       project_name,
                                                       study_date,
                                                       revision)
#get_user()
get_info(ned_req_file)
test()
#get_info(ned_req_file)
print(study_info)
