from dirsync import sync
from StringIO import StringIO
import shutil
import zipfile
import sys, os

directory = os.chdir(os.path.dirname(os.getcwd()))

def recursive_overwrite(src, dest, ignore=None):
    if os.path.isdir(src):
        if not os.path.isdir(dest):
            os.makedirs(dest)
        files = os.listdir(src)
        if ignore is not None:
            ignored = ignore(src, files)
        else:
            ignored = set()
        for f in files:
            if f not in ignored:
                recursive_overwrite(os.path.join(src, f), 
                                    os.path.join(dest, f), 
                                    ignore)
    else:
        shutil.copyfile(src, dest)
old_stdout = sys.stdout
result = StringIO()
sys.stdout = result
sync('./xlsm/', './xlsx/', 'diff') 
sys.stdout = old_stdout
result_string = result.getvalue()

lines = []
for line in result_string.split():
    #if '>>' in line:
    lines.append(line)

ind = [i for i,s in enumerate(lines) if '>>' in s]

copy_items = []
for i in ind:
    item = lines[i+1]
    copy_items.append(item)
    src = './xlsm/' + item
    dst = src.replace('xlsm', 'xlsx')
    #print(dst)
    recursive_overwrite(src, dest, ignore=None)

z = zipfile.ZipFile('2.zip', 'w')

os.chdir('./xlsx')

for root, dirs, files in os.walk('./'):
        for file in files:
            z.write(os.path.join(root, file))
z.close()

os.rename('2.zip', '2.xlsm')
	


#print(copy_items)