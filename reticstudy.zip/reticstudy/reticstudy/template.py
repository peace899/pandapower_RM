from openpyxl import load_workbook
wb = load_workbook(filename = 'rns_template.xltm')

sheet_names = wb.get_sheet_names()
print(sheet_names)