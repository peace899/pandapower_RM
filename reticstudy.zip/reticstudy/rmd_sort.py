import os
import re

rmd_file = 'C:\Users\lekalap\Documents\Work\MIdrand\CROWTHORNE WITPOORTJIE 1 11kV MV Feeder Overhead Line 2015_9_29 8_56_59.rmd'



tfrf_node_names = []


def nodes(rmd_file):
    with open(rmd_file, 'rb') as f:
        txtfile = f.read()
        node_file = txtfile.split('END Nodes')[1].split("END Branches")[0]
        nodes = [n.replace('\n', '') for n in node_file.split('\r')]
        nodes = [n for n in nodes if n is not '']
        return nodes
        
        
def spans(rmd_file):
    with open(rmd_file) as f:
        spans = []
        lines = f.read().splitlines()
        for line in lines:
            if 'Conductor' in line or 'Cable' in line:
                try:
                    span = line.replace('"', "'").split("'")
                    span_node = span[1]
                    span_conductor = span[5]
                    span_name = span[19]
                    span_length = span[6]
                    row = span_node, span_conductor,span_name, span_length
                    spans.append(row)
                except:
                    pass
        return spans

        
def breaker_data(rmd_file):
    with open(rmd_file) as f:
        breakers =[]
        lines = f.read().splitlines()
        for line in lines:
            if 'Breaker' in line:
                switch = line.replace('"', "'").split("'")
                switch_node = switch[1]
                switch_type = switch[19]
                row = switch_node, switch_type
                breakers.append(row)
        return breakers

                
def isolator_data(rmd_file):
    with open(rmd_file) as f:
        isolators = []
        lines = f.read().splitlines()
        for line in lines:   
            if 'Isolator' in line:
                switch = line.replace('"', "'").split("'")
                switch_node = switch[1]
                switch_type = switch[19]
                row = switch_node, switch_type
                isolators.append(row)
        return isolators

        
def trfr_data(rmd_file):
    with open(rmd_file) as f:
        transformers = []
        lines = f.read().splitlines()
        for line in lines:                      
            if 'Trfr' in line:
                trfr = line.replace('"', "'").split("'")
                trfr_node = trfr[1]
                trfr_type = trfr[3]
                trfr_size = trfr[3].split()[0]
                trfr_locale = trfr[15].split()[6]
                row = trfr_node, trfr_type, trfr_size, trfr_locale
                transformers.append(row)
        return transformers
        

def fuse_data(rmd_file):
    with open(rmd_file) as f:
        dropout_fuses = []
        for line in lines:
            if 'DOEF' in line:
                fuse = line.replace('"', "'").split("'")
                fuse_node = fuse[1]
                fuse_name = fuse[19]
                fuse_locale = fuse_name.split()[6]
                row = fuse_node, fuse_name, fuse_locale
                dropout_fuses.append(row)
        return dropout_fuses
                        


def load_data(rmd_file):
    with open(rmd_file) as f:
        loads = []
        for line in lines:
            if 'Customers' in line:
                load = line.split() 
                load_node = load[6].replace('"', '')
                load_voltage = load[8].replace('"', '')
                load_locale = load[54]
                row = load_node, load_locale, load_voltage
                loads.append(row)
        return loads
        

def installed_capacity(rmd_file):
    trfr_sizes = []
    for trfr in trfr_data(rmd_file):
        trfr_size = int(re.sub('[^0-9]','', trfr[2]))
        trfr_sizes.append(trfr_size)
    return sum(trfr_sizes)


def rmd_data(rmd_file, *args):
    if 'trfr' in args[0] and 'size' in args[1]:
        for trfr in trfr_data(rmd_file):
            if args[2] in trfr:
                return re.sub('[^0-9]','', trfr[2])
                
    if 'transformers' in args[0]:
        return trfr_data(rmd_file)
    
    
    if 'installed_capacity' in args[0]:
        return installed_capacity(rmd_file)
        
    
#print(rmd_data(rmd_file, 'trfr', 'size', 'CWI124/7'))